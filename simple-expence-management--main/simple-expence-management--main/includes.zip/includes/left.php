<div class="left">
    <div class="menu">
        <ul>
            <a href="profile.php">
                <li>profile</li>
            </a>
            <a href="dashboard.php">
                <li>dashboard</li>
            </a>
            <a href="categories.php">
                <li>categories</li>
            </a>
            <a href="expenses.php">
                <li>expenses</li>
            </a>
            <a href="logout.php">
                <li>logout</li>
            </a>
        </ul>
    </div>
</div>